﻿================================================================================
  NAUTILUS LOGISTICS AI - WINDOWS DESKTOP EXECUTABLE APPLICATION
================================================================================

Version: 2.0.0 (Production Release)
Platform: Microsoft Windows 10 / 11 (64-bit)
Developer: Nautilus Maritime AI Technologies

--------------------------------------------------------------------------------
1. QUICK START:
--------------------------------------------------------------------------------
Simply double-click:
    -> "Nautilus Logistics AI.exe"

The application will automatically start its high-performance local engine and 
launch the standalone Nautilus Logistics AI desktop window.

--------------------------------------------------------------------------------
2. CREATE DESKTOP SHORTCUT:
--------------------------------------------------------------------------------
You have 3 convenient ways to create a Desktop Shortcut:

Option A (Automatic Prompt):
  On first launch, the app will ask if you want to create a desktop shortcut. 
  Click "Yes".

Option B (System Tray Menu):
  While the app is running, right-click the Nautilus anchor icon in your 
  Windows System Tray (bottom-right near clock) and select:
  "Create Desktop Shortcut".

Option C (1-Click Batch Helper):
  Double-click "Create Desktop Shortcut.bat" inside this folder anytime.

--------------------------------------------------------------------------------
3. SECURITY & ANTIVIRUS COMPATIBILITY:
--------------------------------------------------------------------------------
- Built as a standard native Windows Win32 application with official PE metadata.
- 100% clean, no packers, no third-party wrappers, and zero virus heuristics.
- Runs with standard user privileges (asInvoker) requiring no Administrator elevation.
- Safe for enterprise firewalls, Microsoft SmartScreen, and Windows Defender.

--------------------------------------------------------------------------------
4. SYSTEM TRAY CONTROLS:
--------------------------------------------------------------------------------
When Nautilus Logistics AI is running, an icon appears in your System Tray:
- Left-click or double-click: Open / Focus the application window.
- Right-click: Access menu options:
    * Open Nautilus Logistics AI
    * Create Desktop Shortcut
    * Open in Default Browser
    * Open App Folder
    * Exit Application

--------------------------------------------------------------------------------
5. TECHNICAL ARCHITECTURE:
--------------------------------------------------------------------------------
- Core Engine: Native C/C++ Multi-threaded Local Server (Port 8765 auto-bind)
- UI Frontend: Liquid Glass React 18 + Vite + TailwindCSS + Recharts + Leaflet
- AI Models: SagarSetu Multi-factor Optimizer & KAVACH Cyclone Intelligence
================================================================================
