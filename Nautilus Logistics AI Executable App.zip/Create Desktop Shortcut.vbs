Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\Nautilus Logistics AI.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
sCurrentDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
oLink.TargetPath = sCurrentDir & "\Nautilus Logistics AI.exe"
oLink.WorkingDirectory = sCurrentDir
oLink.IconLocation = sCurrentDir & "\Nautilus Logistics AI.exe,0"
oLink.Description = "Nautilus Logistics AI - Maritime Freight Optimization & Cyclone Intelligence"
oLink.Save
WScript.Echo "Desktop shortcut 'Nautilus Logistics AI' was created successfully on your Desktop!"
