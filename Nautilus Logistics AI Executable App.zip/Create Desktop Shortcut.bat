@echo off
setlocal
cd /d "%~dp0"
title Nautilus Logistics AI - Desktop Shortcut Setup
echo ============================================================
echo   Nautilus Logistics AI - Desktop Shortcut Setup
echo ============================================================
echo.
echo Creating Desktop shortcut for Nautilus Logistics AI...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Nautilus Logistics AI.lnk'); $Shortcut.TargetPath = '%~dp0Nautilus Logistics AI.exe'; $Shortcut.WorkingDirectory = '%~dp0'; $Shortcut.IconLocation = '%~dp0Nautilus Logistics AI.exe,0'; $Shortcut.Description = 'Nautilus Logistics AI - Maritime Freight Optimization Platform'; $Shortcut.Save();"
if %ERRORLEVEL% equ 0 (
    echo.
    echo [SUCCESS] Desktop shortcut 'Nautilus Logistics AI' was created on your Desktop!
) else (
    echo.
    echo [INFO] Creating via VBScript fallback...
    cscript //nologo "Create Desktop Shortcut.vbs"
)
echo.
echo You can now launch Nautilus Logistics AI directly from your Desktop.
echo.
pause
